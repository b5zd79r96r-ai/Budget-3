# Payday Budget App V3

Mobile-first PWA for a 28-day / 13-payday budget system.

## V3 additions
- Smart dashboard with safe-to-spend, daily allowance, next payday countdown, alerts and budget-vs-actual.
- Guided payday workflow: income, bills, allocations, Revolut transfer, close payday.
- Automatic recurring bill scheduling by due day, including bills that occur twice in one 28-day cycle.
- Actual amount overrides per bill without changing the planned amount.
- Closed payday history snapshots so later settings changes do not rewrite historical results.
- Savings goals with targets, target dates, progress and estimated completion based on contribution history.
- Backup export/import.
- Existing V1 localStorage data migration.
- No-zoom mobile viewport retained.

## Netlify
Upload the CONTENTS of this folder to your existing Netlify site. Because the local storage key is preserved, existing V1 data on the same site/domain is migrated rather than intentionally wiped.

## Important
Data remains local to the device/browser. Cloud account sync is not active yet. Export backups regularly until a backend is connected.
